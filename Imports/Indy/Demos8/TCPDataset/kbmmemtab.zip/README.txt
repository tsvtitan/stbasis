TkbmMEMTABLE v. 2.01 (8. Feb. 2000)
=========================================================================
An in-memory temporary table.

BEFORE USING THIS COMPONENT, YOU ARE REQUESTED TO READ ALL OF THIS TEXT
DOCUMENT AND SPECIALLY TO NOTICE AND ACCEPT THE DISCLAIMER.

Can be used as a demonstration of how to create descendents of TDataSet,
or as in my case, to allow a program to generate temporary data that can
be used directly by all data aware controls.

Copyright 1999 Kim Bo Madsen/Optical Services - Scandinavia
All rights reserved.

You are allowed to used this component in any project for free.
You are NOT allowed to claim that you have created this component or to
copy its code into your own component and claim that is was your idea.
I�m offering this for free for your convenience, and the ONLY thing I
DEMAND is to get an e-mail about what project this component (or derived
versions) is used for. That will be my reward of offering this component
for free to you!

You don�t need to state my name in your software, although it would be
Appreciated if you do.

If you find bugs or alter the component (f.ex. see suggested
enhancements further down), please DONT just send the corrected/new code
out on the Internet, but instead send it to me, so I can put it into the
official version. You will be accredited if you do so.

To use it, some fields has to be defined, either programmatically by
setting up fielddefs, or by double-clicking TkbmMemTable icon on the
form.
  - Rightclick to get menu.
  - Choose New field.
  - Specify field name and type + optionally size (only for strings).
  - Make sure that fieldtype is Data.
  - Add more optional data, calculated or lookup fields if needed.
The field definitions will be stored on the form automatically if created
this way.

To use it:
Use it like any other TTable. E.g.: Open, Add records, Read records, Close.
Remember that when the close is issued, all records are forgotten, unless
you have manually saved them, or defined a persistent file.

Please see the comments in the start of the component source for what�s
new in this release.

DISCLAIMER
By using this component or parts thereof you are accepting the full
responsibility of it�s use. You agree to not hold the author responsible
in any way for any problems occurring from the use of this component.
You also recognize the author as the creator of this component and agree
not to claim otherwise!

Please forward corrected versions (source code ONLY!), comments,
and emails saying you are using it for this or that project to:
   kbm@optical.dk
or
   to the memtable community at memtable@onelist.com
//=============================================================================

Support:
   - Look for new versions at:
        - The memory table community - http://www.onelist.com/community/memtable
        - Torry's Delphi Pages       - http://www.torry.ru
        - Delphi Super Pages
        - http://www.optical.dk

   - Join the memory table community by sending an empty e-mail to:
	memtable-subscribe@onelist.com or use a browser to go to 
        http://www.onelist.com/community/memtable

   - Leave the memory table community by sending an empty e-mail to:
	memtable-unsubscribe@onelist.com

   - For more information about the list, please look at: http://www.onelist.com/community/memtable

Whats new since v. 1.37 (the last 1.xx version)
------------------------------------------------

New stuff:
   NEW - Unlimited number of real Indexes controlled by IndexDefs
   NEW - Several index related support properties and methods.
   NEW - AttachTo property to share data between several memorytables.
   NEW - AttachedAutoRefresh property to set automatic refresh of all dataaware
         controls on all attached memorytables.
   NEW - TkbmMemTable is now thread safe.
   NEW - Borrow structure from another dataset in the designer.
   NEW - Enhanced performance in several situations.
   NEW - Internal record validity checks.
   NEW - Method PackTable to finally remove 'deleted' records.
   NEW - Support for ftADT and ftArray fieldtypes for D4/D5/BCB4
   NEW - RangeActive property to determine if a range is active.
   NEW - Demo project updated.
   NEW - Threaded demo project added.
   NEW - Saveoptions for Commatext property.
   NEW - UpdateToDataSet for syncing data with another dataset.
 
Fixes/enhancements:
   Fixed ftBytes bug.
   Fixed Enable/Disablecontrols bug.
   Fixed bugs in SearchRecordID.
   Fixed/enhanced bookmarks.
   Enhanced Lookup.
   Enhanced CancelRange.
   Fixed D4 installation.
   Fixed CompareBookmarks.
   Fixed BCB4 installation.

Examples of other interesting stuff included:
   Threaded dataset controller,
   Full TDataset compatibility,
   CompareBookmark,BookmarkValid,SetKey,EditKey,GotoKey,FindKey,FindNearest,SetRange,
   SetRangeStart,SetRangeEnd,EditRangeStart,EditRangeEnd,ApplyRange,CancelRange,
   Autosorting on insert/edit, binary save/load incl. structure and compression, ftLargeInt,
   Blobs,D5 component editor, French/German/English/Russian/Portoguese/
   Brasilian/Italian/Spanish/Romanian/Slovakian translations and alot more.

Documentation:
   Please check out the demo projects, and read the comments in the top of the sourcefile.

History:
   Please look in top of the sourcefile.

Contributors:
   Claude Rieth from Computer Team sarl (clrieth@team.lu)
   Wagner ADP (wagner@cads-informatica.com.br)
   Charlie McKeegan from Task Software Limited (charlie@task.co.uk)
   James Baile (James@orchiddata.demon.co.uk)
   Travis Diamond (tdiamond@airmail.net)
   Claudio Driussi (c.driussi@popmail.iol.it)
   Andrius Adamonis (andrius@prototechnika.lt)
   Pascalis Bochoridis from SATO S.A Greece (pbohor@sato.gr}
   Thomas Bogenrieder (tbogenrieder@wuerzburg.netsurf.de)
   Paulo Conzon (paolo.conzon@smc.it)
   Ars�ne von Wyss (arsene@vonwyss.ch)
   Raymond J. Schappe (rschappe@isthmus-ts.com)
   Bruno Depero (bdepero@usa.net)
   Denis Tsyplakov (den@vrn.sterling.ru)
   Jason Wharton (jwharton@ibobjects.com)
   Paul Moorcroft (pmoor@netspace.net.au)
   Jir� Hostinsk� (tes@pce.cz)
   Roberto Jimenez (mroberto@jaca.cetuc.puc-rio.br)
   Azuer (blue@nexmil.net)
   Lars S�ndergaard (ls@lunatronic.dk)
   Dirk Carstensen (D.Carstensen@FH-Wolfenbuettel.DE)
   I. M. M. Vatopediou (monh@vatopedi.thessal.singular.gr)
   Kanca (kanca@ibm.net)
   Fernando (tolentino@atalaia.com.br)
   Albert Research (albertrs@redestb.es)
   John Knipper (knipjo@altavista.net)
   Vasil (vasils@ru.ru)
   Javier Tari Agullo (jtari@cyber.es)
   Roman Olexa (systech@ba.telecom.sk)
   Sorin Pohontu (spohontu@assist.cccis.ro)
   Edison Mera Men�ndez (edmera@yahoo.com)
   Dick Boogaers (d.boogaers@css.nl)
   Stas Antonov (hcat@hypersoft.ru)
   Francisco Reyes (francisco@natserv.com)